// src/config.ts
var DEFAULT_API_URL = "https://api.jobhunti.space/api";
var DEFAULT_FRONTEND_URL = "https://jobhunti.space";

// src/background.ts
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["apiUrl", "frontendUrl"]).then((stored) => {
    return chrome.storage.local.set({
      apiUrl: stored.apiUrl ?? DEFAULT_API_URL,
      frontendUrl: stored.frontendUrl ?? DEFAULT_FRONTEND_URL
    });
  });
});
