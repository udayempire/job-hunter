// src/config.ts
var DEFAULT_API_URL = "https://api.jobhunti.space/api";
var DEFAULT_FRONTEND_URL = "https://jobhunti.space";

// src/popup.ts
var companyInput = document.querySelector("#company");
var titleInput = document.querySelector("#title");
var applyLinkInput = document.querySelector("#applyLink");
var detailsUrlInput = document.querySelector("#detailsUrl");
var form = document.querySelector("#job-form");
var saveButton = document.querySelector("#save");
var signInLink = document.querySelector("#sign-in");
var openJobLink = document.querySelector("#open-job");
var message = document.querySelector("#message");
var accountLabel = document.querySelector("#account");
var accountLink = document.querySelector("#account-link");
var capturedDetailsUrl = "";
var capturedSource = "";
function setMessage(text, kind) {
  if (!message)
    return;
  message.textContent = text;
  message.className = kind ? `message ${kind}` : "message";
}
function fillForm(job) {
  if (companyInput)
    companyInput.value = job.company ?? "";
  if (titleInput)
    titleInput.value = job.title ?? "";
  if (applyLinkInput)
    applyLinkInput.value = job.applyLink ?? "";
  if (detailsUrlInput)
    detailsUrlInput.value = job.detailsUrl ?? "";
  capturedDetailsUrl = job.detailsUrl ?? "";
  capturedSource = job.source ?? "";
}
async function sendContentMessage(tabId, message2) {
  try {
    return await chrome.tabs.sendMessage(tabId, message2);
  } catch {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    return chrome.tabs.sendMessage(tabId, message2);
  }
}
function showSignInLink(frontendUrl) {
  if (!signInLink)
    return;
  signInLink.href = `${frontendUrl}/login?returnTo=%2Fhome`;
  signInLink.hidden = false;
}
function showJobLink(frontendUrl, jobId) {
  if (!openJobLink)
    return;
  openJobLink.href = `${frontendUrl}/jobs/${encodeURIComponent(jobId)}`;
  openJobLink.hidden = false;
}
async function loadAccount() {
  const stored = await chrome.storage.local.get(["apiUrl", "frontendUrl"]);
  const apiUrl = stored.apiUrl ?? DEFAULT_API_URL;
  const frontendUrl = stored.frontendUrl ?? DEFAULT_FRONTEND_URL;
  try {
    const response = await fetch(`${apiUrl}/auth/me`, { credentials: "include", cache: "no-store" });
    if (!response.ok) {
      if (accountLabel)
        accountLabel.textContent = "Not signed in";
      showSignInLink(frontendUrl);
      return;
    }
    const payload = await response.json();
    const handle = payload.data?.profile?.handle;
    if (!handle) {
      if (accountLabel)
        accountLabel.textContent = "Signed in · public username unavailable";
      return;
    }
    if (accountLabel)
      accountLabel.textContent = "Signed in as";
    if (accountLink) {
      accountLink.textContent = `@${handle}`;
      accountLink.href = `${frontendUrl}/profile/${encodeURIComponent(handle)}`;
      accountLink.hidden = false;
    }
  } catch {
    if (accountLabel)
      accountLabel.textContent = "Account unavailable";
  }
}
async function captureActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id)
    return;
  try {
    const captured = await sendContentMessage(tab.id, { type: "extract-job" });
    fillForm(captured);
  } catch {
    fillForm({ applyLink: tab.url, title: tab.title });
    setMessage("This page needs a quick manual review.");
  }
}
async function useSelectedText(target) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id)
    return;
  try {
    const response = await sendContentMessage(tab.id, { type: "get-selection" });
    if (!response.selection) {
      setMessage("Select some text on the page first.", "error");
      return;
    }
    if (target === "company" && companyInput)
      companyInput.value = response.selection;
    if (target === "title" && titleInput)
      titleInput.value = response.selection;
    setMessage(`Selected text used as ${target === "company" ? "company" : "role"}.`, "success");
  } catch {
    setMessage("This page does not allow selected-text capture.", "error");
  }
}
async function saveJob(event) {
  event.preventDefault();
  if (!companyInput || !titleInput || !applyLinkInput || !detailsUrlInput || !saveButton)
    return;
  const applyLink = applyLinkInput.value.trim();
  const detailsUrl = detailsUrlInput.value.trim();
  if (!applyLink && !detailsUrl) {
    setMessage("Add an apply link or job details URL.", "error");
    return;
  }
  const job = {
    company: companyInput.value.trim() || "Unnamed company",
    title: titleInput.value.trim() || undefined,
    applyLink: applyLink || undefined,
    detailsUrl: detailsUrl || capturedDetailsUrl || undefined,
    source: capturedSource || new URL(detailsUrl || applyLink).hostname
  };
  saveButton.disabled = true;
  if (openJobLink)
    openJobLink.hidden = true;
  setMessage("Saving…");
  try {
    const stored = await chrome.storage.local.get("apiUrl");
    const apiUrl = stored.apiUrl ?? DEFAULT_API_URL;
    const request = () => fetch(`${apiUrl}/jobs`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(job)
    });
    let response = await request();
    if (response.status === 401) {
      const refresh = await fetch(`${apiUrl}/auth/refresh`, { method: "POST", credentials: "include" });
      if (refresh.ok)
        response = await request();
    }
    if (response.status === 401) {
      const frontendUrl = stored.frontendUrl ?? DEFAULT_FRONTEND_URL;
      showSignInLink(frontendUrl);
      throw new Error("Sign in to Job Hunti, then reopen the extension.");
    }
    const storedFrontendUrl = stored.frontendUrl ?? DEFAULT_FRONTEND_URL;
    if (response.status === 409) {
      const duplicate = await response.json();
      if (duplicate.data?.id)
        showJobLink(storedFrontendUrl, duplicate.data.id);
      setMessage("Job already saved.");
      return;
    }
    if (!response.ok)
      throw new Error("Unable to save this job right now.");
    const payload = await response.json();
    if (payload.data?.id)
      showJobLink(storedFrontendUrl, payload.data.id);
    setMessage("Job saved to Job Hunti.", "success");
  } catch (error) {
    setMessage(error instanceof Error ? error.message : "Unable to save this job right now.", "error");
  } finally {
    saveButton.disabled = false;
  }
}
form?.addEventListener("submit", saveJob);
document.querySelectorAll("[data-selection-target]").forEach((button) => {
  button.addEventListener("click", () => {
    const target = button.dataset.selectionTarget;
    if (target === "company" || target === "title")
      useSelectedText(target);
  });
});
loadAccount();
captureActiveTab();
